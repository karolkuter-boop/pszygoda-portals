#version 400 compatibility
#define WORLD_KRAWEDZ
#define WORLD_OVERWORLD
#define PROGRAM_COMPOSITE0
#define fsh
#include "/program/c0_vl.fsh"
