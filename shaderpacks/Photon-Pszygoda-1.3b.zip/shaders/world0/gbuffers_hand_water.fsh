#version 400 compatibility
#define WORLD_OVERWORLD
#define PROGRAM_GBUFFERS_HAND_WATER
#define fsh
#include "/program/gbuffers_all_translucent.fsh"
