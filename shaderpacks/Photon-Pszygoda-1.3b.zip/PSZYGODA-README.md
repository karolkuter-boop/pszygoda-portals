# Photon Pszygoda 1.3b

This is a modpack derivative of Photon 1.3b for Pszygoda Portals.

Changes from upstream:

- Iris `clouds=fancy` is enabled.
- Photon's no-op `gbuffers_clouds` programs are omitted so Iris routes native
  Minecraft cloud geometry through `gbuffers_textured`.
- Photon's volumetric cloud layers are disabled by default to avoid drawing
  two cloud systems at once.
- TAA stays disabled by default because Immersive Portals cannot render it
  correctly while a portal is visible. Motion blur was already disabled.

Photon's original LICENSE is included unchanged. This derivative is
redistributed only as part of the Pszygoda Portals modpack.
