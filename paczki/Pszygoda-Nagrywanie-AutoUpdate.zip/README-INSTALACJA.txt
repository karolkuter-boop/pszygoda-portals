Pszygoda Nagrywanie - instalacja (PrismLauncher / MultiMC)

99% odcinka: gra na serwerze pszygodacraft.csrv.gg, nagrywanie Flashbackiem.

1. Pobierz ten plik ZIP.
2. W PrismLauncher: Dodaj instancje -> Import z pliku ZIP -> wskaz ten plik.
3. Uruchom instancje. Przy kazdym starcie paczka sama sie aktualizuje
   (Packwiz, kanal: nagrywanie). Pierwszy start trwa dluzej - pobiera mody.
4. Zaloguj sie swoim kontem Minecraft (Microsoft).

Wersja paczki: 1.0.0-nagrywanie.2
Kanal aktualizacji: https://raw.githubusercontent.com/karolkuter-boop/pszygoda-portals/nagrywanie/pack.toml
