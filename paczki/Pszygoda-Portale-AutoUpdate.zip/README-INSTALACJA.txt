Pszygoda Portale - instalacja (PrismLauncher / MultiMC)

Scena z portalami: swiat hostuje dealerke przez Essential (Invite Friends), nagranie na zywo.

1. Pobierz ten plik ZIP.
2. W PrismLauncher: Dodaj instancje -> Import z pliku ZIP -> wskaz ten plik.
3. Uruchom instancje. Przy kazdym starcie paczka sama sie aktualizuje
   (Packwiz, kanal: main). Pierwszy start trwa dluzej - pobiera mody.
4. Zaloguj sie swoim kontem Minecraft (Microsoft).

Wersja paczki: 1.0.0-portals.26
Kanal aktualizacji: https://raw.githubusercontent.com/karolkuter-boop/pszygoda-portals/main/pack.toml
